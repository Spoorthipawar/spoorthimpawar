const axios = null; // placeholder to keep dependency-free; using global fetch (Node 18+)

// Generates a video meeting link for a confirmed booking.
// If Zoom Server-to-Server OAuth credentials are configured, creates a real
// Zoom meeting. Otherwise, falls back to a manual placeholder that the
// stylist can edit from the admin dashboard (e.g. a Google Meet link).
async function createVideoMeeting({ topic, startTime, durationMinutes }) {
  const { ZOOM_ACCOUNT_ID, ZOOM_CLIENT_ID, ZOOM_CLIENT_SECRET } = process.env;

  if (!ZOOM_ACCOUNT_ID || !ZOOM_CLIENT_ID || !ZOOM_CLIENT_SECRET) {
    return {
      provider: 'manual',
      joinUrl: 'https://meet.google.com/replace-with-real-link',
      hostUrl: 'https://meet.google.com/replace-with-real-link',
      meetingId: null
    };
  }

  try {
    // Step 1: get OAuth token
    const tokenRes = await fetch(
      `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${ZOOM_ACCOUNT_ID}`,
      {
        method: 'POST',
        headers: {
          Authorization:
            'Basic ' + Buffer.from(`${ZOOM_CLIENT_ID}:${ZOOM_CLIENT_SECRET}`).toString('base64')
        }
      }
    );
    const tokenData = await tokenRes.json();

    // Step 2: create the meeting
    const meetingRes = await fetch('https://api.zoom.us/v2/users/me/meetings', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        topic,
        type: 2,
        start_time: startTime,
        duration: durationMinutes,
        settings: { join_before_host: false, waiting_room: true }
      })
    });
    const meeting = await meetingRes.json();

    return {
      provider: 'zoom',
      joinUrl: meeting.join_url,
      hostUrl: meeting.start_url,
      meetingId: String(meeting.id)
    };
  } catch (err) {
    console.error('Zoom meeting creation failed, falling back to manual link:', err.message);
    return {
      provider: 'manual',
      joinUrl: 'https://meet.google.com/replace-with-real-link',
      hostUrl: 'https://meet.google.com/replace-with-real-link',
      meetingId: null
    };
  }
}

module.exports = { createVideoMeeting };
