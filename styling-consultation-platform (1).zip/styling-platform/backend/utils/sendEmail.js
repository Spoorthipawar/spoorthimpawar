const nodemailer = require('nodemailer');

// Reusable transporter. In production swap to SendGrid/SES/Postmark - this
// nodemailer SMTP setup is provided so the demo works with any SMTP account.
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: Number(process.env.EMAIL_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

const sendEmail = async ({ to, subject, html }) => {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
    console.warn('Email not sent (EMAIL_USER/EMAIL_PASS not configured):', subject);
    return;
  }
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || process.env.EMAIL_USER,
      to,
      subject,
      html
    });
  } catch (err) {
    console.error('Email send failed:', err.message);
  }
};

module.exports = sendEmail;
