const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema(
  {
    client: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
    date: { type: Date, required: true },
    status: {
      type: String,
      enum: ['pending_payment', 'confirmed', 'completed', 'cancelled'],
      default: 'pending_payment'
    },
    paymentStatus: { type: String, enum: ['unpaid', 'paid', 'refunded'], default: 'unpaid' },
    stripeSessionId: String,
    amountPaid: Number,
    videoMeeting: {
      provider: { type: String, enum: ['zoom', 'google_meet', 'manual'], default: 'manual' },
      joinUrl: String,
      hostUrl: String,
      meetingId: String
    },
    clientNotes: String,
    stylistNotes: String
  },
  { timestamps: true }
);

module.exports = mongoose.model('Booking', bookingSchema);
