const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    slug: { type: String, required: true, unique: true },
    description: { type: String, required: true },
    durationMinutes: { type: Number, required: true, default: 60 },
    price: { type: Number, required: true },
    category: { type: String, enum: ['wardrobe', 'event', 'personal-shopping', 'color-analysis', 'other'], default: 'other' },
    isActive: { type: Boolean, default: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Service', serviceSchema);
