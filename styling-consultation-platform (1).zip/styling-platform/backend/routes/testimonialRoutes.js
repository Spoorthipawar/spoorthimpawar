const express = require('express');
const { getTestimonials, submitTestimonial, approveTestimonial } = require('../controllers/testimonialController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', getTestimonials);
router.post('/', submitTestimonial);
router.put('/:id/approve', protect, adminOnly, approveTestimonial);

module.exports = router;
