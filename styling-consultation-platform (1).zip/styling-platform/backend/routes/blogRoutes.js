const express = require('express');
const { getPublishedPosts, getPostBySlug, createPost } = require('../controllers/blogController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', getPublishedPosts);
router.get('/:slug', getPostBySlug);
router.post('/', protect, adminOnly, createPost);

module.exports = router;
