const express = require('express');
const { createCheckoutSession, stripeWebhook } = require('../controllers/paymentController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/create-checkout-session', protect, createCheckoutSession);
// NOTE: the webhook route uses express.raw() body parsing, wired up in server.js
router.post('/webhook', stripeWebhook);

module.exports = router;
