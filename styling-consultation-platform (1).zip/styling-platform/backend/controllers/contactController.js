const Contact = require('../models/Contact');
const sendEmail = require('../utils/sendEmail');

const submitContact = async (req, res) => {
  const { name, email, message } = req.body;
  const entry = await Contact.create({ name, email, message });

  sendEmail({
    to: process.env.EMAIL_USER,
    subject: `New contact form message from ${name}`,
    html: `<p>${message}</p><p>Reply to: ${email}</p>`
  });

  res.status(201).json({ message: 'Message received, thank you!', id: entry._id });
};

module.exports = { submitContact };
