const Service = require('../models/Service');

const getServices = async (req, res) => {
  const services = await Service.find({ isActive: true }).sort('price');
  res.json(services);
};

const createService = async (req, res) => {
  try {
    const service = await Service.create(req.body);
    res.status(201).json(service);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

const updateService = async (req, res) => {
  const service = await Service.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!service) return res.status(404).json({ message: 'Service not found' });
  res.json(service);
};

const deleteService = async (req, res) => {
  const service = await Service.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
  if (!service) return res.status(404).json({ message: 'Service not found' });
  res.json({ message: 'Service deactivated' });
};

module.exports = { getServices, createService, updateService, deleteService };
