const Stripe = require('stripe');
const Booking = require('../models/Booking');
const Service = require('../models/Service');
const sendEmail = require('../utils/sendEmail');
const { createVideoMeeting } = require('../utils/videoLink');

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder');

// @route POST /api/payments/create-checkout-session
// Creates a Stripe Checkout session for a given booking.
const createCheckoutSession = async (req, res) => {
  try {
    const { bookingId } = req.body;
    const booking = await Booking.findById(bookingId).populate('service').populate('client');
    if (!booking) return res.status(404).json({ message: 'Booking not found' });
    if (String(booking.client._id) !== String(req.user._id)) {
      return res.status(403).json({ message: 'Not your booking' });
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      customer_email: booking.client.email,
      line_items: [
        {
          price_data: {
            currency: 'aud',
            product_data: { name: booking.service.title },
            unit_amount: booking.service.price
          },
          quantity: 1
        }
      ],
      success_url: `${process.env.CLIENT_URL}/dashboard?payment=success&booking=${booking._id}`,
      cancel_url: `${process.env.CLIENT_URL}/dashboard?payment=cancelled`,
      metadata: { bookingId: String(booking._id) }
    });

    booking.stripeSessionId = session.id;
    await booking.save();

    res.json({ url: session.url });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @route POST /api/payments/webhook
// Stripe calls this when checkout completes. Confirms booking + generates video link.
const stripeWebhook = async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const booking = await Booking.findById(session.metadata.bookingId)
      .populate('service')
      .populate('client');

    if (booking) {
      booking.paymentStatus = 'paid';
      booking.status = 'confirmed';
      booking.amountPaid = session.amount_total;

      const meeting = await createVideoMeeting({
        topic: `${booking.service.title} with ${booking.client.name}`,
        startTime: booking.date,
        durationMinutes: booking.service.durationMinutes
      });
      booking.videoMeeting = meeting;

      await booking.save();

      sendEmail({
        to: booking.client.email,
        subject: 'Payment received - consultation confirmed',
        html: `<p>Thanks ${booking.client.name}! Your payment was received and your consultation is confirmed. Join link: ${meeting.joinUrl}</p>`
      });
    }
  }

  res.json({ received: true });
};

module.exports = { createCheckoutSession, stripeWebhook };
