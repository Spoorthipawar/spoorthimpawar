const BlogPost = require('../models/BlogPost');

const getPublishedPosts = async (req, res) => {
  const posts = await BlogPost.find({ isPublished: true }).sort('-createdAt');
  res.json(posts);
};

const getPostBySlug = async (req, res) => {
  const post = await BlogPost.findOne({ slug: req.params.slug, isPublished: true });
  if (!post) return res.status(404).json({ message: 'Post not found' });
  res.json(post);
};

const createPost = async (req, res) => {
  const post = await BlogPost.create({ ...req.body, author: req.user._id });
  res.status(201).json(post);
};

module.exports = { getPublishedPosts, getPostBySlug, createPost };
