const Booking = require('../models/Booking');
const Service = require('../models/Service');
const sendEmail = require('../utils/sendEmail');

// @route POST /api/bookings  (creates a pending booking, before payment)
const createBooking = async (req, res) => {
  try {
    const { serviceId, date, clientNotes } = req.body;
    const service = await Service.findById(serviceId);
    if (!service || !service.isActive) return res.status(404).json({ message: 'Service not found' });

    const booking = await Booking.create({
      client: req.user._id,
      service: service._id,
      date,
      clientNotes,
      status: 'pending_payment'
    });

    res.status(201).json(booking);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// @route GET /api/bookings/mine
const getMyBookings = async (req, res) => {
  const bookings = await Booking.find({ client: req.user._id })
    .populate('service')
    .sort('-date');
  res.json(bookings);
};

// @route GET /api/bookings (admin - all bookings)
const getAllBookings = async (req, res) => {
  const bookings = await Booking.find()
    .populate('service')
    .populate('client', 'name email phone')
    .sort('-date');
  res.json(bookings);
};

// @route PUT /api/bookings/:id/status (admin)
const updateBookingStatus = async (req, res) => {
  const { status, stylistNotes } = req.body;
  const booking = await Booking.findById(req.params.id).populate('client').populate('service');
  if (!booking) return res.status(404).json({ message: 'Booking not found' });

  if (status) booking.status = status;
  if (stylistNotes !== undefined) booking.stylistNotes = stylistNotes;
  await booking.save();

  if (status === 'confirmed') {
    sendEmail({
      to: booking.client.email,
      subject: 'Your styling consultation is confirmed',
      html: `<p>Hi ${booking.client.name}, your ${booking.service.title} consultation on ${new Date(
        booking.date
      ).toLocaleString()} is confirmed. ${
        booking.videoMeeting?.joinUrl ? `Join link: ${booking.videoMeeting.joinUrl}` : ''
      }</p>`
    });
  }

  res.json(booking);
};

module.exports = { createBooking, getMyBookings, getAllBookings, updateBookingStatus };
