const Testimonial = require('../models/Testimonial');

const getTestimonials = async (req, res) => {
  const testimonials = await Testimonial.find({ isApproved: true }).sort('-createdAt');
  res.json(testimonials);
};

const submitTestimonial = async (req, res) => {
  const testimonial = await Testimonial.create(req.body);
  res.status(201).json(testimonial);
};

const approveTestimonial = async (req, res) => {
  const testimonial = await Testimonial.findByIdAndUpdate(
    req.params.id,
    { isApproved: true },
    { new: true }
  );
  res.json(testimonial);
};

module.exports = { getTestimonials, submitTestimonial, approveTestimonial };
