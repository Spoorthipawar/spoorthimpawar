# Styled by Aanya — Online Styling Consultation Platform

A full-stack starter for an online styling consultation business: React/Tailwind frontend,
Node/Express backend, MongoDB database, JWT auth, Stripe payments, and automatic video-call
link generation (Zoom, with a Google Meet fallback).

## Stack

| Layer     | Tech |
|-----------|------|
| Frontend  | React 18 + Vite + React Router + Tailwind CSS |
| Backend   | Node.js + Express (REST API) |
| Database  | MongoDB (Mongoose) |
| Auth      | JWT, bcrypt password hashing |
| Payments  | Stripe Checkout + webhooks |
| Video     | Zoom Server-to-Server OAuth (auto-generated meeting links), falls back to a manual Google Meet link if Zoom isn't configured |
| Email     | Nodemailer (booking confirmations, contact form) |

## What's included

- **Public pages:** Home, About, Services, Portfolio, Testimonials, Blog/Journal, Contact
- **Auth:** Register / Login (JWT), client profile with style preferences
- **Booking flow:** pick a service + date/time → Stripe Checkout → webhook confirms booking,
  generates the video call link, and emails the client
- **Client dashboard:** view bookings, statuses, and join links
- **Admin dashboard:** view all bookings, change status, basic revenue/booking analytics
- **SEO basics:** meta description, semantic headings, per-page titles (see `index.html` and
  extend with `react-helmet-async` if you want per-route `<title>` tags)
- **Social links:** footer placeholders for Instagram/Pinterest/LinkedIn — swap in real URLs

### Not yet wired up (flagged in the original requirements as optional/advanced)
AI style recommendations, wishlist/favorites, live chat support, and a style quiz aren't built
yet — the schema (`User.styleProfile`) leaves room for a quiz result, and the architecture (REST
API + Mongo) will support these cleanly when you're ready to add them.

## Local setup

### 1. Database
Install MongoDB locally, or create a free MongoDB Atlas cluster and grab its connection string.

### 2. Backend
```bash
cd backend
npm install
cp .env.example .env
# edit .env: set MONGO_URI, JWT_SECRET, and (optionally) Stripe/Zoom/email credentials
npm run dev        # starts on http://localhost:5000
```

Seed sample services, testimonials, and an admin login:
```bash
node seed.js
# creates admin@stylingbiz.com / ChangeMe123! — change this password immediately
```

### 3. Frontend
```bash
cd frontend
npm install
npm run dev         # starts on http://localhost:5173, proxies /api to the backend
```

Open http://localhost:5173.

## Configuring Stripe (payments)

1. Create a Stripe account, grab your test secret key → `STRIPE_SECRET_KEY` in `backend/.env`.
2. Run the Stripe CLI to forward webhooks to your local server while developing:
   ```bash
   stripe listen --forward-to localhost:5000/api/payments/webhook
   ```
   Copy the printed `whsec_...` value into `STRIPE_WEBHOOK_SECRET`.
3. Test the flow with Stripe's test card `4242 4242 4242 4242`, any future expiry/CVC.

Without Stripe keys configured, checkout session creation will fail — this is expected until
you add real (test) keys.

## Configuring video consultations (Zoom)

1. In the Zoom App Marketplace, create a **Server-to-Server OAuth** app.
2. Copy the Account ID, Client ID, and Client Secret into `backend/.env`.
3. Once payment is confirmed, the webhook handler automatically creates a Zoom meeting and
   stores the join/host URLs on the booking.
4. If you skip this, bookings still confirm, but the join link is a placeholder
   (`meet.google.com/replace-with-real-link`) that the stylist can edit manually from the
   admin dashboard until real Zoom credentials are added.

## Configuring email notifications

Set `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_USER`, `EMAIL_PASS` in `backend/.env` (e.g. a Gmail app
password, or swap the transporter in `backend/utils/sendEmail.js` for SendGrid/SES/Postmark in
production). If left blank, emails are skipped (logged to console) so the rest of the app still
works in local dev.

## Deploying

- **Frontend:** `npm run build` in `frontend/`, deploy the `dist/` folder to Vercel, Netlify, or
  any static host.
- **Backend:** deploy to Render, Railway, or a VPS. Point `CLIENT_URL` in `.env` at your deployed
  frontend URL (used for Stripe redirect URLs and CORS).
- **Database:** use MongoDB Atlas in production.
- Remember to switch Stripe keys from test to live mode, and re-point the Stripe webhook URL at
  your deployed backend.

## Project structure

```
styling-platform/
├── backend/
│   ├── config/db.js
│   ├── models/          # User, Service, Booking, Testimonial, BlogPost, Contact
│   ├── controllers/
│   ├── routes/
│   ├── middleware/authMiddleware.js
│   ├── utils/           # generateToken, sendEmail, videoLink (Zoom)
│   ├── server.js
│   └── seed.js
└── frontend/
    └── src/
        ├── pages/        # Home, About, Services, Booking, Dashboard, AdminDashboard, ...
        ├── components/   # Navbar, Footer, ProtectedRoute
        ├── context/AuthContext.jsx
        └── api/axiosClient.js
```

## Security notes for going to production

- Rotate `JWT_SECRET` to a long random value, never commit `.env`.
- Add rate limiting (e.g. `express-rate-limit`) on `/api/auth/*`.
- Add server-side validation (the `express-validator` dependency is already included, not yet
  wired into every route — add checks to `authController` and `bookingController` first).
- Serve over HTTPS in production; Stripe webhooks require a public HTTPS endpoint.
