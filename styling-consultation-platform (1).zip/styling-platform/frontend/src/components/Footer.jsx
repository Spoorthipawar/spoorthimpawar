import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-ink text-porcelain/80 mt-24">
      <div className="max-w-6xl mx-auto px-6 py-14 grid gap-10 md:grid-cols-3">
        <div>
          <p className="font-display text-xl text-porcelain">Styled by Aanya</p>
          <p className="mt-3 text-sm leading-relaxed max-w-xs">
            Online styling consultations from Melbourne, for clients anywhere. Wardrobe edits,
            event looks, personal shopping and colour analysis, all over video call.
          </p>
        </div>
        <div>
          <p className="text-sm uppercase tracking-wider text-gold mb-3">Explore</p>
          <ul className="space-y-2 text-sm">
            <li><Link to="/services" className="hover:text-porcelain">Services</Link></li>
            <li><Link to="/portfolio" className="hover:text-porcelain">Portfolio</Link></li>
            <li><Link to="/blog" className="hover:text-porcelain">Journal</Link></li>
            <li><Link to="/booking" className="hover:text-porcelain">Book a session</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-sm uppercase tracking-wider text-gold mb-3">Follow along</p>
          <ul className="space-y-2 text-sm">
            <li><a href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:text-porcelain">Instagram</a></li>
            <li><a href="https://pinterest.com" target="_blank" rel="noreferrer" className="hover:text-porcelain">Pinterest</a></li>
            <li><a href="https://linkedin.com" target="_blank" rel="noreferrer" className="hover:text-porcelain">LinkedIn</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-porcelain/10 py-5 text-center text-xs text-porcelain/50">
        © {new Date().getFullYear()} Styled by Aanya, Melbourne VIC. All rights reserved.
      </div>
    </footer>
  );
}
