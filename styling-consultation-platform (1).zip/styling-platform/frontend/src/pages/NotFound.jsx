import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="max-w-2xl mx-auto px-6 py-32 text-center">
      <h1 className="font-display text-4xl text-ink mb-4">Page not found</h1>
      <p className="text-ink/60 mb-8">The page you're looking for doesn't exist.</p>
      <Link to="/" className="bg-berry text-porcelain px-6 py-2.5 rounded-full">Back home</Link>
    </div>
  );
}
