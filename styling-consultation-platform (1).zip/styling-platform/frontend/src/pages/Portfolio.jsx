const looks = [
  { title: 'Wedding guest, autumn palette', tag: 'Event' },
  { title: 'Capsule wardrobe, 24 pieces', tag: 'Wardrobe edit' },
  { title: 'Studio brand shoot', tag: 'Personal shopping' },
  { title: 'Winter neutrals, warm undertone', tag: 'Colour analysis' },
  { title: 'Interview looks, three variations', tag: 'Event' },
  { title: 'Weekend-to-work capsule', tag: 'Wardrobe edit' }
];

export default function Portfolio() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-16">
      <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">Portfolio</p>
      <h1 className="font-display text-4xl text-ink mb-10">A few looks from past sessions.</h1>
      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
        {looks.map((look, i) => (
          <div key={i} className="rounded-2xl overflow-hidden border border-ink/10">
            <div className="aspect-[3/4] bg-gradient-to-br from-sage/30 via-porcelain to-gold/30 flex items-center justify-center">
              <span className="font-display text-ink/30 text-sm">Image placeholder</span>
            </div>
            <div className="p-4">
              <p className="text-xs uppercase tracking-wide text-gold mb-1">{look.tag}</p>
              <p className="text-ink">{look.title}</p>
            </div>
          </div>
        ))}
      </div>
      <p className="text-sm text-ink/50 mt-8">
        Replace these placeholders with real client photos (with permission) once you have them.
      </p>
    </div>
  );
}
