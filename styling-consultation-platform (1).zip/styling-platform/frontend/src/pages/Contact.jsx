import { useState } from 'react';
import axiosClient from '../api/axiosClient';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('sending');
    try {
      await axiosClient.post('/contact', form);
      setStatus('sent');
      setForm({ name: '', email: '', message: '' });
    } catch {
      setStatus('error');
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-16">
      <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">Contact</p>
      <h1 className="font-display text-4xl text-ink mb-10">Say hello.</h1>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block text-sm text-ink/60 mb-1.5">Name</label>
          <input
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full border border-ink/20 rounded-lg px-4 py-2.5"
          />
        </div>
        <div>
          <label className="block text-sm text-ink/60 mb-1.5">Email</label>
          <input
            type="email"
            required
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full border border-ink/20 rounded-lg px-4 py-2.5"
          />
        </div>
        <div>
          <label className="block text-sm text-ink/60 mb-1.5">Message</label>
          <textarea
            required
            rows={5}
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            className="w-full border border-ink/20 rounded-lg px-4 py-2.5"
          />
        </div>
        <button type="submit" disabled={status === 'sending'} className="bg-berry text-porcelain px-7 py-3 rounded-full hover:bg-berry-dark disabled:opacity-50">
          {status === 'sending' ? 'Sending…' : 'Send message'}
        </button>
        {status === 'sent' && <p className="text-sage">Thanks — we'll be in touch soon.</p>}
        {status === 'error' && <p className="text-berry">Something went wrong. Please try again.</p>}
      </form>
    </div>
  );
}
