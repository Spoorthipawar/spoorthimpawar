import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const data = await login(email, password);
      navigate(data.role === 'admin' ? '/admin' : '/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed');
    }
  };

  return (
    <div className="max-w-md mx-auto px-6 py-20">
      <h1 className="font-display text-3xl text-ink mb-8">Log in</h1>
      <form onSubmit={handleSubmit} className="space-y-5">
        <input
          type="email"
          required
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full border border-ink/20 rounded-lg px-4 py-2.5"
        />
        <input
          type="password"
          required
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full border border-ink/20 rounded-lg px-4 py-2.5"
        />
        {error && <p className="text-berry text-sm">{error}</p>}
        <button type="submit" className="w-full bg-berry text-porcelain py-3 rounded-full hover:bg-berry-dark">
          Log in
        </button>
      </form>
      <p className="mt-6 text-sm text-ink/60">
        No account yet? <Link to="/register" className="text-berry hover:underline">Register</Link>
      </p>
    </div>
  );
}
