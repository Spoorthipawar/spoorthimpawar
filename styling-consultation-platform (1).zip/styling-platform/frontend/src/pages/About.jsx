export default function About() {
  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">About</p>
      <h1 className="font-display text-4xl md:text-5xl text-ink mb-8">Hi, I'm Aanya.</h1>
      <div className="grid md:grid-cols-3 gap-10">
        <div className="md:col-span-2 space-y-5 text-ink/70 leading-relaxed">
          <p>
            I trained as a professional stylist in Melbourne, and now work with clients everywhere
            over video call. My approach is simple: your style should reflect how you actually
            move through your week, not a mood board.
          </p>
          <p>
            Every consultation starts with listening - to your lifestyle, your budget, and what's
            already sitting in your wardrobe unworn. From there we build outfits, edit what
            doesn't serve you, and put together a shopping list that fills real gaps.
          </p>
          <p>
            I've styled clients for weddings, job interviews, brand shoots, and plain old Tuesdays
            that needed a little more confidence. No two sessions look the same.
          </p>
        </div>
        <div className="bg-porcelain border border-ink/10 rounded-2xl p-6">
          <p className="text-sm uppercase tracking-wide text-gold mb-3">Credentials</p>
          <ul className="text-sm text-ink/70 space-y-2">
            <li>Certified Personal Stylist, Melbourne</li>
            <li>4+ years client-facing styling</li>
            <li>Specialities: colour analysis, capsule wardrobes, event styling</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
