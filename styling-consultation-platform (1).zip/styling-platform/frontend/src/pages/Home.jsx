import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axiosClient from '../api/axiosClient';

export default function Home() {
  const [services, setServices] = useState([]);
  const [testimonials, setTestimonials] = useState([]);

  useEffect(() => {
    axiosClient.get('/services').then((res) => setServices(res.data.slice(0, 3))).catch(() => {});
    axiosClient.get('/testimonials').then((res) => setTestimonials(res.data.slice(0, 2))).catch(() => {});
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-16 pb-24 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">Melbourne, online worldwide</p>
          <h1 className="font-display text-5xl md:text-6xl leading-[1.05] text-ink">
            A wardrobe that already knows who you are.
          </h1>
          <p className="mt-6 text-ink/70 text-lg leading-relaxed max-w-md">
            One-on-one styling consultations over video call, built around your shape, your
            colouring, and your actual life, not a trend cycle.
          </p>
          <div className="mt-9 flex flex-wrap gap-4">
            <Link to="/booking" className="bg-berry text-porcelain px-7 py-3.5 rounded-full hover:bg-berry-dark transition-colors">
              Book a consultation
            </Link>
            <Link to="/services" className="border border-ink/20 text-ink px-7 py-3.5 rounded-full hover:border-ink/50 transition-colors">
              See services
            </Link>
          </div>
        </div>
        <div className="relative">
          <div className="aspect-[4/5] rounded-[2rem] bg-gradient-to-br from-berry via-berry-dark to-ink overflow-hidden flex items-end p-8">
            <p className="font-display text-porcelain text-2xl leading-snug">
              "Clothes should feel like they were always yours."
            </p>
          </div>
          <div className="absolute -bottom-6 -left-6 bg-porcelain border border-ink/10 rounded-2xl px-6 py-4 shadow-sm hidden sm:block">
            <p className="font-display text-3xl text-berry">200+</p>
            <p className="text-xs text-ink/60 uppercase tracking-wide">consultations styled</p>
          </div>
        </div>
      </section>

      {/* Services preview */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="flex items-end justify-between mb-10">
          <h2 className="font-display text-3xl text-ink">Ways to work together</h2>
          <Link to="/services" className="text-sm text-berry hover:underline">View all services</Link>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {services.map((s) => (
            <div key={s._id} className="border border-ink/10 rounded-2xl p-7 hover:border-berry/40 transition-colors">
              <p className="font-display text-xl text-ink mb-2">{s.title}</p>
              <p className="text-sm text-ink/60 leading-relaxed">{s.description}</p>
              <p className="mt-4 text-berry font-medium">${(s.price / 100).toFixed(0)} AUD</p>
            </div>
          ))}
          {services.length === 0 && (
            <p className="text-ink/50 text-sm">Services will appear here once the backend is connected and seeded.</p>
          )}
        </div>
      </section>

      {/* Testimonials preview */}
      {testimonials.length > 0 && (
        <section className="bg-ink text-porcelain py-16">
          <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-10">
            {testimonials.map((t) => (
              <div key={t._id}>
                <p className="font-display text-xl leading-relaxed">"{t.quote}"</p>
                <p className="mt-4 text-sm text-gold">{t.clientName}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-6 py-20 text-center">
        <h2 className="font-display text-3xl text-ink mb-4">Ready for a wardrobe that works?</h2>
        <p className="text-ink/60 mb-8 max-w-md mx-auto">
          Sessions run over video call - just you, your closet or a shopping tab, and an hour of
          undivided attention.
        </p>
        <Link to="/booking" className="bg-berry text-porcelain px-7 py-3.5 rounded-full hover:bg-berry-dark transition-colors">
          Book your session
        </Link>
      </section>
    </div>
  );
}
