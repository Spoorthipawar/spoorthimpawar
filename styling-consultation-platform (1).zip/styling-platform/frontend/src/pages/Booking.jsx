import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axiosClient from '../api/axiosClient';

export default function Booking() {
  const location = useLocation();
  const navigate = useNavigate();
  const [services, setServices] = useState([]);
  const [serviceId, setServiceId] = useState(location.state?.serviceId || '');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [clientNotes, setClientNotes] = useState('');
  const [error, setError] = useState('');
  const [step, setStep] = useState('form'); // form | processing

  useEffect(() => {
    axiosClient.get('/services').then((res) => {
      setServices(res.data);
      if (!serviceId && res.data.length) setServiceId(res.data[0]._id);
    });
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setStep('processing');
    try {
      const dateTime = new Date(`${date}T${time}`);
      const { data: booking } = await axiosClient.post('/bookings', {
        serviceId,
        date: dateTime.toISOString(),
        clientNotes
      });

      const { data: checkout } = await axiosClient.post('/payments/create-checkout-session', {
        bookingId: booking._id
      });

      // Redirects to Stripe Checkout. In this starter project, if Stripe keys
      // are not configured, the backend still returns a session object shape
      // (the request will fail gracefully - see README for setup).
      window.location.href = checkout.url;
    } catch (err) {
      setStep('form');
      setError(err.response?.data?.message || 'Something went wrong creating your booking.');
    }
  };

  return (
    <div className="max-w-xl mx-auto px-6 py-16">
      <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">Booking</p>
      <h1 className="font-display text-4xl text-ink mb-3">Book your session.</h1>
      <p className="text-ink/60 mb-10">
        Choose a service and time. You'll be taken to secure checkout, and a video call link is
        sent automatically once payment is confirmed.
      </p>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block text-sm text-ink/60 mb-1.5">Service</label>
          <select
            value={serviceId}
            onChange={(e) => setServiceId(e.target.value)}
            className="w-full border border-ink/20 rounded-lg px-4 py-2.5 bg-white"
          >
            {services.map((s) => (
              <option key={s._id} value={s._id}>
                {s.title} — ${(s.price / 100).toFixed(0)} AUD
              </option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-ink/60 mb-1.5">Date</label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full border border-ink/20 rounded-lg px-4 py-2.5"
            />
          </div>
          <div>
            <label className="block text-sm text-ink/60 mb-1.5">Time</label>
            <input
              type="time"
              required
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full border border-ink/20 rounded-lg px-4 py-2.5"
            />
          </div>
        </div>
        <div>
          <label className="block text-sm text-ink/60 mb-1.5">Anything to share beforehand? (optional)</label>
          <textarea
            rows={4}
            value={clientNotes}
            onChange={(e) => setClientNotes(e.target.value)}
            className="w-full border border-ink/20 rounded-lg px-4 py-2.5"
            placeholder="Occasion, budget, wardrobe goals…"
          />
        </div>
        {error && <p className="text-berry text-sm">{error}</p>}
        <button
          type="submit"
          disabled={step === 'processing'}
          className="w-full bg-berry text-porcelain py-3.5 rounded-full hover:bg-berry-dark disabled:opacity-50"
        >
          {step === 'processing' ? 'Redirecting to checkout…' : 'Continue to payment'}
        </button>
      </form>
    </div>
  );
}
