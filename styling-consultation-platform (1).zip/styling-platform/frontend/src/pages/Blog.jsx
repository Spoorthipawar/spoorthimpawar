import { useEffect, useState } from 'react';
import axiosClient from '../api/axiosClient';

export default function Blog() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axiosClient.get('/blog').then((res) => setPosts(res.data)).catch(() => {});
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">Journal</p>
      <h1 className="font-display text-4xl text-ink mb-10">Fashion tips & notes.</h1>

      {posts.length === 0 && (
        <p className="text-ink/50">
          No posts published yet — add some from the admin dashboard once the backend is running.
        </p>
      )}

      <div className="space-y-10">
        {posts.map((p) => (
          <article key={p._id} className="border-b border-ink/10 pb-10">
            <p className="text-xs text-ink/40 mb-2">{new Date(p.createdAt).toLocaleDateString()}</p>
            <h2 className="font-display text-2xl text-ink mb-2">{p.title}</h2>
            <p className="text-ink/60 leading-relaxed">{p.excerpt}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
