import { useEffect, useState } from 'react';
import axiosClient from '../api/axiosClient';

export default function Testimonials() {
  const [testimonials, setTestimonials] = useState([]);
  const [form, setForm] = useState({ clientName: '', quote: '', rating: 5 });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    axiosClient.get('/testimonials').then((res) => setTestimonials(res.data)).catch(() => {});
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axiosClient.post('/testimonials', form);
    setSubmitted(true);
    setForm({ clientName: '', quote: '', rating: 5 });
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">Testimonials</p>
      <h1 className="font-display text-4xl text-ink mb-10">What clients say.</h1>

      <div className="space-y-8 mb-16">
        {testimonials.map((t) => (
          <blockquote key={t._id} className="border-l-2 border-berry pl-6">
            <p className="font-display text-xl text-ink leading-relaxed">"{t.quote}"</p>
            <cite className="not-italic text-sm text-ink/50">— {t.clientName}</cite>
          </blockquote>
        ))}
      </div>

      <div className="bg-porcelain border border-ink/10 rounded-2xl p-8">
        <p className="font-display text-xl text-ink mb-4">Share your experience</p>
        {submitted ? (
          <p className="text-sage">Thank you! Your testimonial will appear here once approved.</p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              required
              placeholder="Your name"
              value={form.clientName}
              onChange={(e) => setForm({ ...form, clientName: e.target.value })}
              className="w-full border border-ink/20 rounded-lg px-4 py-2.5 bg-white"
            />
            <textarea
              required
              placeholder="Tell us about your session"
              value={form.quote}
              onChange={(e) => setForm({ ...form, quote: e.target.value })}
              rows={4}
              className="w-full border border-ink/20 rounded-lg px-4 py-2.5 bg-white"
            />
            <button type="submit" className="bg-berry text-porcelain px-6 py-2.5 rounded-full hover:bg-berry-dark">
              Submit
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
