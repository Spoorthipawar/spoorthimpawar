import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axiosClient from '../api/axiosClient';

export default function Services() {
  const [services, setServices] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    axiosClient
      .get('/services')
      .then((res) => setServices(res.data))
      .catch(() => setError('Could not load services right now. Please check back shortly.'));
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-6 py-16">
      <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">Services</p>
      <h1 className="font-display text-4xl text-ink mb-10">Choose what you need right now.</h1>

      {error && <p className="text-berry">{error}</p>}

      <div className="grid md:grid-cols-2 gap-6">
        {services.map((s) => (
          <div key={s._id} className="border border-ink/10 rounded-2xl p-8 flex flex-col">
            <p className="font-display text-2xl text-ink mb-2">{s.title}</p>
            <p className="text-ink/60 leading-relaxed flex-1">{s.description}</p>
            <div className="mt-6 flex items-center justify-between">
              <div className="text-sm text-ink/50">{s.durationMinutes} min · ${(s.price / 100).toFixed(0)} AUD</div>
              <Link
                to="/booking"
                state={{ serviceId: s._id }}
                className="bg-berry text-porcelain text-sm px-5 py-2.5 rounded-full hover:bg-berry-dark transition-colors"
              >
                Book this
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
