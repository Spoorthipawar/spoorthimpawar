import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import axiosClient from '../api/axiosClient';
import { useAuth } from '../context/AuthContext';

const statusLabel = {
  pending_payment: 'Awaiting payment',
  confirmed: 'Confirmed',
  completed: 'Completed',
  cancelled: 'Cancelled'
};

export default function Dashboard() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [searchParams] = useSearchParams();
  const paymentStatus = searchParams.get('payment');

  useEffect(() => {
    axiosClient.get('/bookings/mine').then((res) => setBookings(res.data)).catch(() => {});
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">My account</p>
      <h1 className="font-display text-4xl text-ink mb-2">Hi {user?.name?.split(' ')[0]}.</h1>

      {paymentStatus === 'success' && (
        <div className="bg-sage/10 border border-sage/40 text-sage rounded-lg px-4 py-3 my-6">
          Payment received! Your consultation is confirmed — check below for your video call link.
        </div>
      )}
      {paymentStatus === 'cancelled' && (
        <div className="bg-berry/10 border border-berry/40 text-berry rounded-lg px-4 py-3 my-6">
          Checkout was cancelled. You can try again below.
        </div>
      )}

      <h2 className="font-display text-2xl text-ink mt-10 mb-4">Your consultations</h2>
      <div className="space-y-4">
        {bookings.map((b) => (
          <div key={b._id} className="border border-ink/10 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <p className="font-display text-lg text-ink">{b.service?.title}</p>
              <p className="text-sm text-ink/60">{new Date(b.date).toLocaleString()}</p>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-xs uppercase tracking-wide px-3 py-1 rounded-full bg-porcelain border border-ink/10">
                {statusLabel[b.status]}
              </span>
              {b.videoMeeting?.joinUrl && b.status === 'confirmed' && (
                <a
                  href={b.videoMeeting.joinUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sm text-berry hover:underline"
                >
                  Join video call
                </a>
              )}
            </div>
          </div>
        ))}
        {bookings.length === 0 && <p className="text-ink/50">No bookings yet.</p>}
      </div>
    </div>
  );
}
