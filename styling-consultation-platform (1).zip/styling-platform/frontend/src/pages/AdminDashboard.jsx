import { useEffect, useState } from 'react';
import axiosClient from '../api/axiosClient';

const statuses = ['pending_payment', 'confirmed', 'completed', 'cancelled'];

export default function AdminDashboard() {
  const [bookings, setBookings] = useState([]);
  const [tab, setTab] = useState('bookings');

  const loadBookings = () => axiosClient.get('/bookings').then((res) => setBookings(res.data));

  useEffect(() => {
    loadBookings().catch(() => {});
  }, []);

  const updateStatus = async (id, status) => {
    await axiosClient.put(`/bookings/${id}/status`, { status });
    loadBookings();
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-16">
      <p className="uppercase tracking-[0.2em] text-xs text-gold mb-5">Admin</p>
      <h1 className="font-display text-4xl text-ink mb-10">Studio dashboard.</h1>

      <div className="flex gap-6 border-b border-ink/10 mb-8">
        {['bookings', 'analytics'].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`pb-3 text-sm capitalize ${tab === t ? 'border-b-2 border-berry text-ink' : 'text-ink/50'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'bookings' && (
        <div className="space-y-4">
          {bookings.map((b) => (
            <div key={b._id} className="border border-ink/10 rounded-xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <p className="font-display text-lg text-ink">{b.service?.title}</p>
                  <p className="text-sm text-ink/60">
                    {b.client?.name} · {b.client?.email} · {new Date(b.date).toLocaleString()}
                  </p>
                </div>
                <select
                  value={b.status}
                  onChange={(e) => updateStatus(b._id, e.target.value)}
                  className="border border-ink/20 rounded-lg px-3 py-2 text-sm bg-white"
                >
                  {statuses.map((s) => (
                    <option key={s} value={s}>{s.replace('_', ' ')}</option>
                  ))}
                </select>
              </div>
              {b.videoMeeting?.joinUrl && (
                <p className="text-xs text-ink/50 mt-3">Join link: {b.videoMeeting.joinUrl}</p>
              )}
            </div>
          ))}
          {bookings.length === 0 && <p className="text-ink/50">No bookings yet.</p>}
        </div>
      )}

      {tab === 'analytics' && (
        <div className="grid sm:grid-cols-3 gap-6">
          <div className="border border-ink/10 rounded-xl p-6">
            <p className="text-3xl font-display text-berry">{bookings.length}</p>
            <p className="text-sm text-ink/60">Total bookings</p>
          </div>
          <div className="border border-ink/10 rounded-xl p-6">
            <p className="text-3xl font-display text-berry">
              {bookings.filter((b) => b.status === 'confirmed').length}
            </p>
            <p className="text-sm text-ink/60">Confirmed</p>
          </div>
          <div className="border border-ink/10 rounded-xl p-6">
            <p className="text-3xl font-display text-berry">
              ${(bookings.reduce((sum, b) => sum + (b.amountPaid || 0), 0) / 100).toFixed(0)}
            </p>
            <p className="text-sm text-ink/60">Revenue (AUD)</p>
          </div>
        </div>
      )}
    </div>
  );
}
